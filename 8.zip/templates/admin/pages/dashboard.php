<?php
/**
 * صفحه داشبورد
 */

if (!defined('ABSPATH')) {
    exit;
}

// دریافت آمار
global $wpdb;

// تعداد محصولات
$total_products = wp_count_posts('product');
$published_products = $total_products->publish ?? 0;

// تعداد همگام‌سازی‌های موفق و ناموفق
$sync_table = $wpdb->prefix . 'zargar_sync_queue';
$total_syncs = $wpdb->get_var("SELECT COUNT(*) FROM $sync_table");
$success_syncs = $wpdb->get_var("SELECT COUNT(*) FROM $sync_table WHERE status = 'completed'");
$failed_syncs = $wpdb->get_var("SELECT COUNT(*) FROM $sync_table WHERE status = 'failed'");
$pending_syncs = $wpdb->get_var("SELECT COUNT(*) FROM $sync_table WHERE status = 'pending'");

// آخرین لاگ‌ها
$logs_table = $wpdb->prefix . 'zargar_logs';
$recent_logs = $wpdb->get_results("SELECT * FROM $logs_table ORDER BY created_at DESC LIMIT 5");

// وضعیت اتصال
$api_url = get_option('zargar_api_url', '');
$api_key = get_option('zargar_api_key', '');
$connection_status = (!empty($api_url) && !empty($api_key)) ? 'متصل' : 'غیرمتصل';
$connection_class = (!empty($api_url) && !empty($api_key)) ? 'connected' : 'disconnected';
?>

<div class="wrap zargar-wrap">
    <div class="zargar-header">
        <h1>
            <span class="dashicons dashicons-calculator"></span>
            داشبورد حسابداری زرگر
        </h1>
        <p class="zargar-subtitle">مدیریت اتصال ووکامرس به نرم‌افزار حسابداری زرگر</p>
    </div>

    <div class="zargar-dashboard">
        <!-- کارت‌های آماری -->
        <div class="zargar-stats-grid">
            <!-- محصولات -->
            <div class="zargar-stat-card">
                <div class="stat-icon stat-icon-products">
                    <span class="dashicons dashicons-products"></span>
                </div>
                <div class="stat-content">
                    <h3><?php echo number_format($published_products); ?></h3>
                    <p>محصولات فعال</p>
                </div>
            </div>

            <!-- همگام‌سازی موفق -->
            <div class="zargar-stat-card">
                <div class="stat-icon stat-icon-success">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
                <div class="stat-content">
                    <h3><?php echo number_format($success_syncs); ?></h3>
                    <p>همگام‌سازی موفق</p>
                </div>
            </div>

            <!-- همگام‌سازی ناموفق -->
            <div class="zargar-stat-card">
                <div class="stat-icon stat-icon-error">
                    <span class="dashicons dashicons-dismiss"></span>
                </div>
                <div class="stat-content">
                    <h3><?php echo number_format($failed_syncs); ?></h3>
                    <p>همگام‌سازی ناموفق</p>
                </div>
            </div>

            <!-- در انتظار -->
            <div class="zargar-stat-card">
                <div class="stat-icon stat-icon-pending">
                    <span class="dashicons dashicons-clock"></span>
                </div>
                <div class="stat-content">
                    <h3><?php echo number_format($pending_syncs); ?></h3>
                    <p>در انتظار همگام‌سازی</p>
                </div>
            </div>
        </div>

        <!-- بخش اصلی -->
        <div class="zargar-main-content">
            <!-- ستون راست -->
            <div class="zargar-main-column">
                <!-- وضعیت اتصال -->
                <div class="zargar-card">
                    <div class="zargar-card-header">
                        <h2>
                            <span class="dashicons dashicons-admin-links"></span>
                            وضعیت اتصال
                        </h2>
                    </div>
                    <div class="zargar-card-body">
                        <div class="connection-status <?php echo $connection_class; ?>">
                            <div class="status-indicator"></div>
                            <div class="status-text">
                                <strong><?php echo $connection_status; ?></strong>
                                <?php if (!empty($api_url)): ?>
                                    <p class="status-url"><?php echo esc_html($api_url); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <?php if (empty($api_url) || empty($api_key)): ?>
                            <div class="zargar-alert zargar-alert-warning">
                                <span class="dashicons dashicons-warning"></span>
                                <p>برای استفاده از افزونه، ابتدا تنظیمات اتصال را پیکربندی کنید.</p>
                                <a href="<?php echo admin_url('admin.php?page=zargar-accounting-settings'); ?>" class="button button-primary">
                                    تنظیمات اتصال
                                </a>
                            </div>
                        <?php endif; ?>

                        <div class="connection-actions">
                            <button type="button" class="button" id="test-connection">
                                <span class="dashicons dashicons-update"></span>
                                تست اتصال
                            </button>
                            <button type="button" class="button" id="sync-now">
                                <span class="dashicons dashicons-image-rotate"></span>
                                همگام‌سازی دستی
                            </button>
                        </div>
                    </div>
                </div>

                <!-- آخرین فعالیت‌ها -->
                <div class="zargar-card">
                    <div class="zargar-card-header">
                        <h2>
                            <span class="dashicons dashicons-list-view"></span>
                            آخرین فعالیت‌ها
                        </h2>
                    </div>
                    <div class="zargar-card-body">
                        <?php if (!empty($recent_logs)): ?>
                            <div class="zargar-activity-list">
                                <?php foreach ($recent_logs as $log): ?>
                                    <div class="activity-item log-<?php echo esc_attr($log->log_type); ?>">
                                        <div class="activity-icon">
                                            <span class="dashicons dashicons-info"></span>
                                        </div>
                                        <div class="activity-content">
                                            <p class="activity-message"><?php echo esc_html($log->message); ?></p>
                                            <span class="activity-time"><?php echo human_time_diff(strtotime($log->created_at), current_time('timestamp')); ?> پیش</span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="zargar-card-footer">
                                <a href="<?php echo admin_url('admin.php?page=zargar-accounting-logs'); ?>" class="button">
                                    مشاهده همه لاگ‌ها
                                </a>
                            </div>
                        <?php else: ?>
                            <p class="no-activity">هیچ فعالیتی ثبت نشده است.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- ستون چپ - سایدبار -->
            <div class="zargar-sidebar-column">
                <!-- دسترسی سریع -->
                <div class="zargar-card">
                    <div class="zargar-card-header">
                        <h2>
                            <span class="dashicons dashicons-admin-generic"></span>
                            دسترسی سریع
                        </h2>
                    </div>
                    <div class="zargar-card-body">
                        <div class="quick-links">
                            <a href="<?php echo admin_url('admin.php?page=zargar-accounting-sync'); ?>" class="quick-link">
                                <span class="dashicons dashicons-image-rotate"></span>
                                همگام‌سازی محصولات
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=zargar-accounting-product-mapping'); ?>" class="quick-link">
                                <span class="dashicons dashicons-networking"></span>
                                نقشه‌برداری محصولات
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=zargar-accounting-price-mapping'); ?>" class="quick-link">
                                <span class="dashicons dashicons-money-alt"></span>
                                نقشه‌برداری قیمت
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=zargar-accounting-logs'); ?>" class="quick-link">
                                <span class="dashicons dashicons-list-view"></span>
                                مشاهده لاگ‌ها
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=zargar-accounting-settings'); ?>" class="quick-link">
                                <span class="dashicons dashicons-admin-settings"></span>
                                تنظیمات
                            </a>
                        </div>
                    </div>
                </div>

                <!-- راهنما -->
                <div class="zargar-card">
                    <div class="zargar-card-header">
                        <h2>
                            <span class="dashicons dashicons-book"></span>
                            راهنما و پشتیبانی
                        </h2>
                    </div>
                    <div class="zargar-card-body">
                        <div class="help-links">
                            <a href="<?php echo admin_url('admin.php?page=zargar-accounting-faq'); ?>" class="help-link">
                                <span class="dashicons dashicons-editor-help"></span>
                                سوالات متداول
                            </a>
                            <a href="#" class="help-link" target="_blank">
                                <span class="dashicons dashicons-media-document"></span>
                                مستندات
                            </a>
                            <a href="#" class="help-link" target="_blank">
                                <span class="dashicons dashicons-sos"></span>
                                پشتیبانی
                            </a>
                        </div>
                    </div>
                </div>

                <!-- اطلاعات نسخه -->
                <div class="zargar-card">
                    <div class="zargar-card-header">
                        <h2>
                            <span class="dashicons dashicons-info"></span>
                            اطلاعات
                        </h2>
                    </div>
                    <div class="zargar-card-body">
                        <div class="version-info">
                            <p><strong>نسخه افزونه:</strong> <?php echo ZARGAR_ACCOUNTING_VERSION; ?></p>
                            <p><strong>نسخه وردپرس:</strong> <?php echo get_bloginfo('version'); ?></p>
                            <?php if (class_exists('WooCommerce')): ?>
                                <p><strong>نسخه ووکامرس:</strong> <?php echo WC()->version; ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>