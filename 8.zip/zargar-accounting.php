<?php
/**
 * Autoloader برای بارگذاری خودکار کلاس‌ها
 */

if (!defined('ABSPATH')) {
    exit;
}

class Zargar_Accounting_Loader {
    
    private $actions;
    private $filters;
    
    public function __construct() {
        $this->actions = array();
        $this->filters = array();
    }
    
    /**
     * افزودن اکشن
     */
    public function add_action($hook, $component, $callback, $priority = 10, $accepted_args = 1) {
        $this->actions = $this->add($this->actions, $hook, $component, $callback, $priority, $accepted_args);
    }
    
    /**
     * افزودن فیلتر
     */
    public function add_filter($hook, $component, $callback, $priority = 10, $accepted_args = 1) {
        $this->filters = $this->add($this->filters, $hook, $component, $callback, $priority, $accepted_args);
    }
    
    /**
     * افزودن هوک
     */
    private function add($hooks, $hook, $component, $callback, $priority, $accepted_args) {
        $hooks[] = array(
            'hook'          => $hook,
            'component'     => $component,
            'callback'      => $callback,
            'priority'      => $priority,
            'accepted_args' => $accepted_args
        );
        return $hooks;
    }
    
    /**
     * اجرای تمام هوک‌ها
     */
    public function run() {
        foreach ($this->filters as $hook) {
            add_filter(
                $hook['hook'],
                array($hook['component'], $hook['callback']),
                $hook['priority'],
                $hook['accepted_args']
            );
        }
        
        foreach ($this->actions as $hook) {
            add_action(
                $hook['hook'],
                array($hook['component'], $hook['callback']),
                $hook['priority'],
                $hook['accepted_args']
            );
        }
    }
    
    /**
     * بارگذاری خودکار کلاس‌ها
     */
    public static function autoload($class) {
        if (strpos($class, 'Zargar_Accounting_') !== 0) {
            return;
        }
        
        $class_name = str_replace('Zargar_Accounting_', '', $class);
        $class_name = strtolower($class_name);
        $class_name = str_replace('_', '-', $class_name);
        
        $file = ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/class-' . $class_name . '.php';
        
        if (file_exists($file)) {
            require_once $file;
        }
    }
}

// ثبت autoloader
spl_autoload_register(['Zargar_Accounting_Loader', 'autoload']);