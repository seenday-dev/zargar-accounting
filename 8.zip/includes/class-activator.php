<?php
/**
 * کلاس فعال‌سازی افزونه
 */

if (!defined('ABSPATH')) {
    exit;
}

class Zargar_Accounting_Activator {
    
    public static function activate() {
        // ایجاد جداول دیتابیس
        self::create_tables();
        
        // ایجاد صفحات مورد نیاز
        self::create_pages();
        
        // تنظیمات پیش‌فرض
        self::set_default_options();
        
        // فلاش کردن rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * ایجاد جداول دیتابیس
     */
    private static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // جدول لاگ‌ها
        $table_logs = $wpdb->prefix . 'zargar_logs';
        $sql_logs = "CREATE TABLE IF NOT EXISTS $table_logs (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            log_type varchar(50) NOT NULL,
            message text NOT NULL,
            context longtext,
            user_id bigint(20),
            ip_address varchar(45),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY log_type (log_type),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // جدول صف همگام‌سازی
        $table_sync_queue = $wpdb->prefix . 'zargar_sync_queue';
        $sql_sync_queue = "CREATE TABLE IF NOT EXISTS $table_sync_queue (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            product_id bigint(20) NOT NULL,
            sync_type varchar(50) NOT NULL,
            status varchar(20) DEFAULT 'pending',
            attempt_count int(11) DEFAULT 0,
            last_error text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY product_id (product_id),
            KEY status (status)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_logs);
        dbDelta($sql_sync_queue);
    }
    
    /**
     * ایجاد صفحات مورد نیاز
     */
    private static function create_pages() {
        // در صورت نیاز
    }
    
    /**
     * تنظیمات پیش‌فرض
     */
    private static function set_default_options() {
        $default_options = array(
            'zargar_api_url' => '',
            'zargar_api_key' => '',
            'zargar_api_secret' => '',
            'zargar_sync_enabled' => 'no',
            'zargar_sync_interval' => 'hourly',
            'zargar_log_enabled' => 'yes',
            'zargar_log_level' => 'info',
            'zargar_log_retention_days' => 30,
        );
        
        foreach ($default_options as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }
    }
}