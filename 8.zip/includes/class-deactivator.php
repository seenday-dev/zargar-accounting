<?php
/**
 * کلاس غیرفعال‌سازی افزونه
 */

if (!defined('ABSPATH')) {
    exit;
}

class Zargar_Accounting_Deactivator {
    
    public static function deactivate() {
        // حذف cron jobs
        wp_clear_scheduled_hook('zargar_sync_products');
        
        // فلاش کردن rewrite rules
        flush_rewrite_rules();
    }
}