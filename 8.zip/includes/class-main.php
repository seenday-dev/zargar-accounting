<?php
/**
 * کلاس اصلی افزونه
 */

if (!defined('ABSPATH')) {
    exit;
}

class Zargar_Accounting_Main {
    
    protected $loader;
    protected $version;
    
    public function __construct() {
        $this->version = ZARGAR_ACCOUNTING_VERSION;
        $this->load_dependencies();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }
    
    /**
     * بارگذاری فایل‌های مورد نیاز
     */
    private function load_dependencies() {
        // Admin
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/admin/class-admin.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/admin/class-menu.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/admin/class-settings.php';
        
        // API
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/api/class-api-auth.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/api/class-api-client.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/api/class-api-handler.php';
        
        // Database
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/database/class-db-handler.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/database/class-migrations.php';
        
        // Helpers
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/helpers/class-utils.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/helpers/functions.php';
        
        // Logger
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/logger/class-logger.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/logger/class-log-handler.php';
        
        // Sync
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/sync/class-product-sync.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/sync/class-sync-manager.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/sync/class-sync-queue.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/sync/class-sync-scheduler.php';
        
        // Activator & Deactivator
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/class-activator.php';
        require_once ZARGAR_ACCOUNTING_PLUGIN_DIR . 'includes/class-deactivator.php';
        
        $this->loader = new Zargar_Accounting_Loader();
    }
    
    /**
     * تعریف هوک‌های بخش مدیریت
     */
    private function define_admin_hooks() {
        $admin = new Zargar_Accounting_Admin();
        
        $this->loader->add_action('admin_enqueue_scripts', $admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $admin, 'enqueue_scripts');
        $this->loader->add_action('admin_menu', $admin, 'register_menu');
    }
    
    /**
     * تعریف هوک‌های بخش عمومی
     */
    private function define_public_hooks() {
        // اگر نیاز به هوک‌های عمومی داشتید
    }
    
    /**
     * اجرای افزونه
     */
    public function run() {
        $this->loader->run();
    }
    
    /**
     * دریافت نسخه
     */
    public function get_version() {
        return $this->version;
    }
}