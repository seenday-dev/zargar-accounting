<?php
/**
 * کلاس مدیریت بخش ادمین
 */

if (!defined('ABSPATH')) {
    exit;
}

class Zargar_Accounting_Admin {
    
    private $version;
    
    public function __construct() {
        $this->version = ZARGAR_ACCOUNTING_VERSION;
    }
    
    /**
     * بارگذاری استایل‌ها
     */
    public function enqueue_styles() {
        if (!$this->is_zargar_page()) {
            return;
        }
        
        wp_enqueue_style(
            'zargar-accounting-admin',
            ZARGAR_ACCOUNTING_PLUGIN_URL . 'assets/css/admin-style.css',
            array(),
            $this->version,
            'all'
        );
    }
    
    /**
     * بارگذاری اسکریپت‌ها
     */
    public function enqueue_scripts() {
        if (!$this->is_zargar_page()) {
            return;
        }
        
        wp_enqueue_script(
            'zargar-accounting-admin',
            ZARGAR_ACCOUNTING_PLUGIN_URL . 'assets/js/admin-script.js',
            array('jquery'),
            $this->version,
            true
        );
        
        // ارسال متغیرها به جاوااسکریپت
        wp_localize_script('zargar-accounting-admin', 'zargarAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('zargar_admin_nonce'),
            'pluginUrl' => ZARGAR_ACCOUNTING_PLUGIN_URL,
        ));
    }
    
    /**
     * ثبت منوی مدیریت
     */
    public function register_menu() {
        $menu = new Zargar_Accounting_Menu();
        $menu->register();
    }
    
    /**
     * بررسی صفحه فعلی
     */
    private function is_zargar_page() {
        $screen = get_current_screen();
        return $screen && strpos($screen->id, 'zargar-accounting') !== false;
    }
}