<?php
/**
 * کلاس منوی مدیریت
 */

if (!defined('ABSPATH')) {
    exit;
}

class Zargar_Accounting_Menu {
    
    /**
     * ثبت منو
     */
    public function register() {
        // منوی اصلی
        add_menu_page(
            'حسابداری زرگر',
            'حسابداری زرگر',
            'manage_options',
            'zargar-accounting',
            array($this, 'dashboard_page'),
            'dashicons-calculator',
            30
        );
        
        // داشبورد
        add_submenu_page(
            'zargar-accounting',
            'داشبورد',
            'داشبورد',
            'manage_options',
            'zargar-accounting',
            array($this, 'dashboard_page')
        );
        
        // همگام‌سازی محصولات
        add_submenu_page(
            'zargar-accounting',
            'همگام‌سازی محصولات',
            'همگام‌سازی محصولات',
            'manage_options',
            'zargar-accounting-sync',
            array($this, 'sync_page')
        );
        
        // تنظیمات
        add_submenu_page(
            'zargar-accounting',
            'تنظیمات اتصال',
            'تنظیمات اتصال',
            'manage_options',
            'zargar-accounting-settings',
            array($this, 'settings_page')
        );
        
        // نقشه‌برداری محصولات
        add_submenu_page(
            'zargar-accounting',
            'نقشه‌برداری محصولات',
            'نقشه‌برداری محصولات',
            'manage_options',
            'zargar-accounting-product-mapping',
            array($this, 'product_mapping_page')
        );
        
        // نقشه‌برداری قیمت
        add_submenu_page(
            'zargar-accounting',
            'نقشه‌برداری قیمت',
            'نقشه‌برداری قیمت',
            'manage_options',
            'zargar-accounting-price-mapping',
            array($this, 'price_mapping_page')
        );
        
        // لاگ‌ها
        add_submenu_page(
            'zargar-accounting',
            'لاگ‌ها',
            'لاگ‌ها',
            'manage_options',
            'zargar-accounting-logs',
            array($this, 'logs_page')
        );
        
        // سوالات متداول
        add_submenu_page(
            'zargar-accounting',
            'سوالات متداول',
            'راهنما',
            'manage_options',
            'zargar-accounting-faq',
            array($this, 'faq_page')
        );
    }
    
    /**
     * صفحه داشبورد
     */
    public function dashboard_page() {
        include ZARGAR_ACCOUNTING_PLUGIN_DIR . 'templates/admin/pages/dashboard.php';
    }
    
    /**
     * صفحه همگام‌سازی
     */
    public function sync_page() {
        include ZARGAR_ACCOUNTING_PLUGIN_DIR . 'templates/admin/pages/product-sync-list.php';
    }
    
    /**
     * صفحه تنظیمات
     */
    public function settings_page() {
        include ZARGAR_ACCOUNTING_PLUGIN_DIR . 'templates/admin/pages/settings-connection.php';
    }
    
    /**
     * صفحه نقشه‌برداری محصولات
     */
    public function product_mapping_page() {
        include ZARGAR_ACCOUNTING_PLUGIN_DIR . 'templates/admin/pages/settings-product-mapping.php';
    }
    
    /**
     * صفحه نقشه‌برداری قیمت
     */
    public function price_mapping_page() {
        include ZARGAR_ACCOUNTING_PLUGIN_DIR . 'templates/admin/pages/settings-price-mapping.php';
    }
    
    /**
     * صفحه لاگ‌ها
     */
    public function logs_page() {
        include ZARGAR_ACCOUNTING_PLUGIN_DIR . 'templates/admin/pages/logs-page.php';
    }
    
    /**
     * صفحه سوالات
     */
    public function faq_page() {
        include ZARGAR_ACCOUNTING_PLUGIN_DIR . 'templates/admin/pages/faq-page.php';
    }
}