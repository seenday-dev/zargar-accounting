<?php
/**
 * Field Mapper Helper
 * 
 * نقشه‌برداری و اعمال فیلدهای زرگر به محصولات WooCommerce
 * 
 * @package ZargarAccounting
 * @since 2.0.0
 */

namespace ZargarAccounting\Helpers;

if (!defined('ABSPATH')) {
    exit;
}

class FieldMapper {
    
    /**
     * دریافت لیست فیلدهای قابل import
     */
    public static function getAvailableFields(): array {
        return [
            'basic' => [
                'title' => 'اطلاعات اصلی',
                'fields' => [
                    'ProductId' => ['label' => 'شناسه محصول', 'target' => 'meta:_external_id'],
                    'ProductCode' => ['label' => 'کد محصول (SKU)', 'target' => 'sku'],
                    'ProductTitle' => ['label' => 'عنوان محصول', 'target' => 'post_title'],
                ]
            ],
            'weight' => [
                'title' => 'وزن و اندازه',
                'fields' => [
                    'Weight' => ['label' => 'وزن', 'target' => 'meta:_weight'],
                    'BaseWeight' => ['label' => 'وزن پایه', 'target' => 'meta:_base_weight'],
                    'WeightSymbolRate' => ['label' => 'نرخ نماد وزن', 'target' => 'meta:_weight_symbol_rate'],
                ]
            ],
            'stock' => [
                'title' => 'موجودی و دسته‌بندی',
                'fields' => [
                    'IsExists' => ['label' => 'وضعیت موجودی', 'target' => 'stock_status'],
                    'CategoryTitle' => ['label' => 'دسته‌بندی', 'target' => 'term:product_cat'],
                    'LocationTitle' => ['label' => 'مکان', 'target' => 'meta:_location'],
                ]
            ],
            'images' => [
                'title' => 'تصاویر',
                'fields' => [
                    'DefaultImageURL' => ['label' => 'تصویر شاخص', 'target' => 'featured_image'],
                    'ImageURL1' => ['label' => 'تصویر گالری 1', 'target' => 'gallery_image'],
                    'ImageURL2' => ['label' => 'تصویر گالری 2', 'target' => 'gallery_image'],
                    'ImageURL3' => ['label' => 'تصویر گالری 3', 'target' => 'gallery_image'],
                    'ImageURL4' => ['label' => 'تصویر گالری 4', 'target' => 'gallery_image'],
                    'ImageURL5' => ['label' => 'تصویر گالری 5', 'target' => 'gallery_image'],
                    'ImageURL6' => ['label' => 'تصویر گالری 6', 'target' => 'gallery_image'],
                ]
            ],
            'attributes' => [
                'title' => 'ویژگی‌ها',
                'fields' => [
                    'ModelTitle' => ['label' => 'مدل', 'target' => 'attribute:model'],
                    'ColorTitle' => ['label' => 'رنگ', 'target' => 'attribute:pa_color'],
                    'SizeTitle' => ['label' => 'سایز', 'target' => 'attribute:pa_size'],
                    'CollectionTitle' => ['label' => 'کلکسیون', 'target' => 'attribute:collection'],
                ]
            ],
            'pricing' => [
                'title' => 'قیمت‌گذاری',
                'fields' => [
                    'GoldPrice' => ['label' => 'قیمت طلا', 'target' => 'regular_price'],
                    'StonePrice' => ['label' => 'قیمت سنگ', 'target' => 'meta:_stone_price'],
                    'WageOfPrice' => ['label' => 'اجرت', 'target' => 'meta:_wage_price'],
                    'TotalPrice' => ['label' => 'قیمت نهایی', 'target' => 'sale_price'],
                ]
            ],
            'tax' => [
                'title' => 'مالیات و درآمد',
                'fields' => [
                    'TaxPercent' => ['label' => 'درصد مالیات', 'target' => 'tax_class'],
                    'IncomeTotal' => ['label' => 'مجموع درآمد', 'target' => 'meta:_income_total'],
                    'TaxTotal' => ['label' => 'مجموع مالیات', 'target' => 'meta:_tax_total'],
                ]
            ],
            'sales' => [
                'title' => 'اجرت فروش',
                'fields' => [
                    'SaleWageOfPercent' => ['label' => 'درصد اجرت فروش', 'target' => 'meta:_sale_wage_percent'],
                    'SaleWageOfPrice' => ['label' => 'مبلغ اجرت فروش', 'target' => 'meta:_sale_wage_price'],
                    'SaleWageOfPriceType' => ['label' => 'نوع اجرت فروش', 'target' => 'meta:_sale_wage_price_type'],
                    'SaleStonePrice' => ['label' => 'قیمت سنگ فروش', 'target' => 'meta:_sale_stone_price'],
                ]
            ],
            'codes' => [
                'title' => 'کدهای اضافی',
                'fields' => [
                    'OldCode' => ['label' => 'کد قدیمی', 'target' => 'meta:_old_code'],
                    'OfficeCode' => ['label' => 'کد دفتر', 'target' => 'meta:_office_code'],
                    'DesignerCode' => ['label' => 'کد طراح', 'target' => 'meta:_designer_code'],
                ]
            ],
        ];
    }
    
    /**
     * اعمال فیلدهای انتخاب شده به محصول
     */
    public function applyFieldsToProduct(\WC_Product $product, array $productData, array $selectedFields): void {
        foreach ($selectedFields as $fieldName) {
            if (!isset($productData[$fieldName])) {
                continue;
            }
            
            $value = $productData[$fieldName];
            $target = $this->getFieldTarget($fieldName);
            
            if (!$target) {
                continue;
            }
            
            $this->applyField($product, $target, $value, $fieldName, $productData);
        }
    }
    
    /**
     * دریافت target یک فیلد
     */
    private function getFieldTarget(string $fieldName): ?string {
        $allFields = self::getAvailableFields();
        
        foreach ($allFields as $category) {
            if (isset($category['fields'][$fieldName])) {
                return $category['fields'][$fieldName]['target'];
            }
        }
        
        return null;
    }
    
    /**
     * اعمال یک فیلد به محصول
     */
    private function applyField(\WC_Product $product, string $target, $value, string $fieldName, array $productData): void {
        // Meta field
        if (strpos($target, 'meta:') === 0) {
            $metaKey = str_replace('meta:', '', $target);
            $product->update_meta_data($metaKey, $value);
            return;
        }
        
        // Attribute
        if (strpos($target, 'attribute:') === 0) {
            $attrName = str_replace('attribute:', '', $target);
            $this->setProductAttribute($product, $attrName, $value);
            return;
        }
        
        // Term (Category)
        if (strpos($target, 'term:') === 0) {
            $taxonomy = str_replace('term:', '', $target);
            $this->setProductTerm($product, $taxonomy, $value);
            return;
        }
        
        // Gallery Image
        if ($target === 'gallery_image') {
            $this->addGalleryImage($product, $value);
            return;
        }
        
        // Featured Image
        if ($target === 'featured_image') {
            $this->setFeaturedImage($product, $value);
            return;
        }
        
        // Direct WooCommerce fields
        switch ($target) {
            case 'sku':
                $product->set_sku($value);
                break;
            case 'post_title':
                $product->set_name($value);
                break;
            case 'regular_price':
                $product->set_regular_price($value);
                break;
            case 'sale_price':
                $product->set_sale_price($value);
                break;
            case 'stock_status':
                $status = $value ? 'instock' : 'outofstock';
                $product->set_stock_status($status);
                break;
            case 'tax_class':
                $product->set_tax_class($value);
                break;
        }
    }
    
    /**
     * تنظیم attribute محصول
     */
    private function setProductAttribute(\WC_Product $product, string $attrName, $value): void {
        $attributes = $product->get_attributes();
        
        $attribute = new \WC_Product_Attribute();
        $attribute->set_name($attrName);
        $attribute->set_options([$value]);
        $attribute->set_visible(true);
        $attribute->set_variation(false);
        
        $attributes[$attrName] = $attribute;
        $product->set_attributes($attributes);
    }
    
    /**
     * تنظیم term (دسته‌بندی)
     */
    private function setProductTerm(\WC_Product $product, string $taxonomy, string $termName): void {
        if (empty($termName)) {
            return;
        }
        
        $term = term_exists($termName, $taxonomy);
        
        if (!$term) {
            $term = wp_insert_term($termName, $taxonomy);
        }
        
        if (!is_wp_error($term)) {
            $termId = is_array($term) ? $term['term_id'] : $term;
            wp_set_object_terms($product->get_id(), $termId, $taxonomy);
        }
    }
    
    /**
     * افزودن تصویر به گالری
     */
    private function addGalleryImage(\WC_Product $product, string $imageUrl): void {
        if (empty($imageUrl)) {
            return;
        }
        
        $attachmentId = $this->downloadAndAttachImage($imageUrl);
        
        if ($attachmentId) {
            $galleryIds = $product->get_gallery_image_ids();
            $galleryIds[] = $attachmentId;
            $product->set_gallery_image_ids($galleryIds);
        }
    }
    
    /**
     * تنظیم تصویر شاخص
     */
    private function setFeaturedImage(\WC_Product $product, string $imageUrl): void {
        if (empty($imageUrl)) {
            return;
        }
        
        $attachmentId = $this->downloadAndAttachImage($imageUrl);
        
        if ($attachmentId) {
            $product->set_image_id($attachmentId);
        }
    }
    
    /**
     * دانلود و ضمیمه کردن تصویر
     */
    private function downloadAndAttachImage(string $imageUrl): ?int {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        $tmp = download_url($imageUrl);
        
        if (is_wp_error($tmp)) {
            return null;
        }
        
        $fileName = basename($imageUrl);
        
        $file = [
            'name' => $fileName,
            'tmp_name' => $tmp
        ];
        
        $attachmentId = media_handle_sideload($file, 0);
        
        if (is_wp_error($attachmentId)) {
            @unlink($tmp);
            return null;
        }
        
        return $attachmentId;
    }
}
