<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? 'Zargar Accounting'); ?> - حسابداری زرگر</title>
    
    <link rel="stylesheet" href="<?php echo e($plugin_url); ?>assets/css/main.css">
    <link rel="stylesheet" href="<?php echo e($plugin_url); ?>assets/css/sidebar.css">
    <link rel="stylesheet" href="<?php echo e($plugin_url); ?>assets/css/dashboard.css">
    <link rel="stylesheet" href="<?php echo e($plugin_url); ?>assets/css/forms.css">
    <link rel="stylesheet" href="<?php echo e($plugin_url); ?>assets/css/logs.css">
</head>
<body class="zargar-accounting">
    <div class="zargar-wrap">
        <div class="zargar-header">
            <h1><?php echo e($title ?? 'حسابداری زرگر'); ?></h1>
            <div class="zargar-header-info">
                <span>کاربر: <?php echo e($current_user->display_name); ?></span>
            </div>
        </div>
<?php /**PATH /home/morpheus/Documents/zargar-accounting/templates/components/header.blade.php ENDPATH**/ ?>