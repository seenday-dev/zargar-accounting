<nav aria-label="breadcrumb">
    <ol class="zargar-breadcrumb">
        <li><a href="admin.php">خانه</a></li>
        <?php if(isset($breadcrumbs) && is_array($breadcrumbs)): ?>
            <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($crumb['url'])): ?>
                    <li><a href="<?php echo e($crumb['url']); ?>"><?php echo e($crumb['title']); ?></a></li>
                <?php else: ?>
                    <li class="active"><?php echo e($crumb['title']); ?></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ol>
</nav>

<style>
    .zargar-breadcrumb {
        list-style: none;
        display: flex;
        padding: 15px 30px;
        background: #e9ecef;
        font-size: 13px;
        margin: 0;
    }
    
    .zargar-breadcrumb li {
        display: flex;
        align-items: center;
    }
    
    .zargar-breadcrumb li:not(:last-child)::after {
        content: "←";
        margin: 0 10px;
        color: #6c757d;
    }
    
    .zargar-breadcrumb a {
        color: #667eea;
        text-decoration: none;
    }
    
    .zargar-breadcrumb a:hover {
        text-decoration: underline;
    }
    
    .zargar-breadcrumb li.active {
        color: #495057;
        font-weight: bold;
    }
</style>
<?php /**PATH /home/morpheus/Documents/zargar-accounting/templates/partials/breadcrumb.blade.php ENDPATH**/ ?>