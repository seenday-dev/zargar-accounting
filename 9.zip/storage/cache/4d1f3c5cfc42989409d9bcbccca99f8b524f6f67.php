<?php echo $__env->make('components.header', ['title' => 'داشبورد'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="zargar-content-wrapper">
    <aside class="zargar-sidebar-wrapper">
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </aside>
    
    <main class="zargar-main-content">
        <?php echo $__env->make('partials.breadcrumb', [
            'breadcrumbs' => [
                ['title' => 'حسابداری زرگر'],
                ['title' => 'داشبورد']
            ]
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="content-inner">
            <div class="dashboard-widgets">
                <div class="widget">
                    <div class="widget-content">
                        <div class="widget-icon">
                            <span class="dashicons dashicons-chart-line"></span>
                        </div>
                        <div class="widget-info">
                            <div class="widget-label">تراکنش امروز</div>
                            <div class="widget-value">1,234</div>
                            <div class="widget-change positive">↑ 12.5%</div>
                        </div>
                    </div>
                </div>
                
                <div class="widget">
                    <div class="widget-content">
                        <div class="widget-icon">
                            <span class="dashicons dashicons-yes-alt"></span>
                        </div>
                        <div class="widget-info">
                            <div class="widget-label">نرخ موفقیت</div>
                            <div class="widget-value">98.5%</div>
                            <div class="widget-change positive">↑ 2.1%</div>
                        </div>
                    </div>
                </div>
                
                <div class="widget">
                    <div class="widget-content">
                        <div class="widget-icon">
                            <span class="dashicons dashicons-update"></span>
                        </div>
                        <div class="widget-info">
                            <div class="widget-label">آخرین همگام‌سازی</div>
                            <div class="widget-value">15</div>
                            <div class="widget-change">دقیقه پیش</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-card">
                <div class="dashboard-card-header">
                    <h2 class="dashboard-card-title">خوش آمدید به حسابداری زرگر</h2>
                    <a href="?page=zargar-accounting-settings" class="dashboard-card-action">تنظیمات</a>
                </div>
                <div class="dashboard-card-content">
                    <p>این پنل مدیریت سیستم حسابداری زرگر است. سیستمی حرفه‌ای برای مدیریت حسابداری طلافروشی‌ها با تکنولوژی روز.</p>
                    <p style="margin-top: 12px;">از منوی کناری می‌توانید به بخش‌های مختلف دسترسی داشته باشید.</p>
                </div>
            </div>
        </div>
    </main>
</div>

<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/morpheus/Documents/zargar-accounting/templates/admin/dashboard.blade.php ENDPATH**/ ?>