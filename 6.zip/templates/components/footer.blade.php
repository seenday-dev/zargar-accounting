        <div class="zargar-footer">
            <p>&copy; {{ date('Y') }} حسابداری زرگر - نسخه {{ $plugin_version }}</p>
        </div>
    </div>
    
    <script src="{{ $plugin_url }}assets/js/main.js"></script>
</body>
</html>
