        <div class="zargar-footer">
            <p>&copy; <?php echo e(date('Y')); ?> حسابداری زرگر - نسخه <?php echo e($plugin_version); ?></p>
        </div>
    </div>
    
    <script src="<?php echo e($plugin_url); ?>assets/js/main.js"></script>
</body>
</html>
<?php /**PATH /home/morpheus/Documents/zargar-accounting/templates/components/footer.blade.php ENDPATH**/ ?>